<?xml version='1.0' encoding='UTF-8'?>
<?profile version='1.0.0'?>
<profile id='DefaultProfile' timestamp='1772521971678'>
  <properties size='5'>
    <property name='org.eclipse.equinox.p2.cache' value='/var/lib/jenkins/workspace/iDempiere12Daily/org.idempiere.p2/target/products/org.adempiere.server.product/linux/gtk/x86_64'/>
    <property name='org.eclipse.update.install.features' value='true'/>
    <property name='org.eclipse.equinox.p2.roaming' value='false'/>
    <property name='org.eclipse.equinox.p2.environments' value='osgi.os=linux,osgi.arch=x86_64,osgi.ws=gtk,osgi.nl=en_US'/>
    <property name='org.eclipse.equinox.p2.installFolder' value='/var/lib/jenkins/workspace/iDempiere12Daily/org.idempiere.p2/target/products/org.adempiere.server.product/linux/gtk/x86_64'/>
  </properties>
</profile>
